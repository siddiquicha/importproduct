<?php
class Webapp_Magmiuploader_IndexController extends Mage_Core_Controller_Front_Action{
	
    public function IndexAction() {
		$getCSvData = Mage::getModel('magmiuploader/cron')->getCsv();
		
		if(!empty($getCSvData))
		{
			Mage::log('Successfully import csv', null, 'importsuccessstatus.log');
		}else{
			Mage::log(print_r($getCSvData), null, 'importErrorstatus.log');			
		}
    }
}