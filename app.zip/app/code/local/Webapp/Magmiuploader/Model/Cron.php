<?php
$setrequire_Url = Mage::getBaseDir()."/magmi/plugins/inc/magmi_datasource.php";
$setrequire_Url1 = Mage::getBaseDir()."/magmi/integration/inc/productimport_datapump.php";

require_once($setrequire_Url);
require_once($setrequire_Url1);

/*
*** set automate magmi uploader from cron based to system based
** return class to set uploader csv file from the path
*/
class Webapp_Magmiuploader_Model_Cron{	
	
	/*
	*** function call to cron tab hit and upload csv
	** upload new csv file magento
	*/
	public function magmiUpdate($items){

         $this->import($items);
	}
	
	/*
	*** Get all csv file from the path cron task like /var/crontask
	** return function to get csv file from the path.
	*/
	
	public function getCsv()
	{
		try{
			$setOrderCsv = array();
			$getUrlData = Mage::app()->getRequest()->getParams();
		
			$csvdirectory = Mage::getBaseDir()."/var/crontask";
			
			foreach($getUrlData as $value)
			{
				$getDataValue = explode(",", $value);
			}
			if(!empty($getDataValue))
			{
				foreach($getDataValue as $_item)
				{
					$filename = $_item.".csv";
					//echo $filename."\n";
					if(file_exists($csvdirectory."/".$filename))
					  $setOrderCsv[$filename] = $filename;
					else
					{
					  for($filename_nr = 0; $filename_nr <= 49 ; $filename_nr++) 
					  {
						$filename = $_item."-".$filename_nr.".csv";
						//echo $filename."\n";
						if(file_exists($csvdirectory."/".$filename))
				{          
						  $setOrderCsv[$filename] = $filename;
				  //We should only import one of the $filename_nr. Reason is that if we choose all $filename_nr's, that the whole import of CSV's takes long time. 
				   break;              
				}            
					  }
					}
			
				if (count($setOrderCsv)>0)
			{
			  //We should only import one of the $filename_nr. Reason is that if we choose all $filename_nr's, that the whole import of CSV's takes long time. 
			  break;   
			}
				}
			}
			else
			{
				//$setOrderCsv = array('insert'=>'magmi_products_inserter.csv', 'description'=>'magmi_description_updater.csv', 'picture'=>'magmi_image_updater.csv', 'price'=>'magmi_price_updater.csv', 'status'=>'magmi_products_status_updater.csv', 'update'=>'magmi_products_mega_updater.csv', 'filter'=>'magmi_serachfilter_updater.csv');
				$setOrderCsv = array();			
			}
			// echo "<pre>";
			// print_r($setOrderCsv);
			// die("stop");

			$inprocess_file = $csvdirectory."/"."magmi_in_process.prc";
		if (count($setOrderCsv)>0)
		{
			if(!file_exists($inprocess_file))
			{
				$inprocess =array();
				$create = fopen($csvdirectory."/"."magmi_in_process.prc", "w") or die("Unable to open file!");
				$message = "file already inprocess";
				fwrite($create, $message);
				fclose($create);
				$success['start_date'] = date('Y-m-d H:i:s');	
				// loop for csv update
				foreach($setOrderCsv as $csv)
			{
					$csvName = $csvdirectory."/"."$csv";
					if(file_exists($csvName)){
						$this->openCsv($csvName);
						$success['CsvName'] =$csv;
						unlink($csvName);
					}
				}
				// remove inprocess file
				unlink($inprocess_file);
				// remove file from directory
				$success['Message'] = "Successfully import csv file";
				$this->getSuccessEmail(json_encode($success));				
			}
		  else
		  {
				$message ="magmi_in_process file already exist";
				$this->getInprocessEmail($message);			
			}  
		}
		elseif ((count($setOrderCsv)==0) && (file_exists($inprocess_file)))
		{
		  // remove inprocess file
				unlink($inprocess_file); 
		}
	}catch(Exception $e)
		{
			Mage::log($e->getMessage(), null, 'getCsvdata.log');
		}
	}
	
	/*
	*** open csv to read data from csv file 
	*/
	
	public function openCsv($csv_item)
	{
		$Items = array();
		$csvData = fopen($csv_item, "r");
		$listData =fgetcsv($csvData);
		
		// set search filter updater
		$pathArr = explode(DIRECTORY_SEPARATOR, $csv_item);
		$filename = end($pathArr);
		// if(stripos($filename,'magmi_serachfilter_updater') !== FALSE)
		// {
			// $this->getAttributeCreate($listData);
		// }	
		
		//We need to strtolower here because all attributes are been strtolower!
    foreach ($listData as $listData_key => $listData_value)
    {
      $listData[$listData_key] = strtolower($listData_value);
    }
    
    $line_data = array();
		while(!feof($csvData))
		{	
			$data_array = fgetcsv($csvData);
			if(!empty($data_array))
      {
        foreach($data_array as $key=>$value)
				{                                                                        
// 					$line_data[$key] = iconv("UTF-8", "ISO-8859-2//TRANSLIT", trim($value));
					$line_data[$key] = $value;
				}
					$Items[] = array_combine($listData, $line_data);					
			}
		}
		fclose($csvData);
		$this->magmiUpdate($Items);
	}
	
	/*
	*** Read data from import function
	*/	
	private function import($items, $mode = 'create', $indexes = 'all')
  {
    if (count($items) > 0) 
    {
      $dp = new Magmi_ProductImport_DataPump();
      $dp->beginImportSession("default", $mode);
		  $line_data = array();
  		$error_message = array();
  
  		//echo "<pre>";
  		//print_r($items);
  		//die('check the');
  		foreach ($items as $item) 
      {
				foreach($item as $key=>$value)
				{
					$line_data[$key] = utf8_encode(trim($value,'"'));
				}
  			try{
  					$dp->ingest($line_data);
  			}catch(Exception $e)
  			{
  				$error_message['Error_Message'] = $e->getMessage();
  				Mage::log('Error->'.$e->getMessage(), null, 'importline.log');
  			}
      }
  		if(!empty($error_message))
      {
  			$this->getErrorEmail(json_encode($error_message));						
  		}
      $dp->endImportSession();
      //$this->reindex($indexes);
    }
  }

	/*
	*** Reindex after data import
	*/
    private function reindex($string = 'all')
    {
        /** @var $indexer Mage_Index_Model_Indexer */
        $indexer = Mage::getModel('index/indexer');
        $processes = array();

        if ($string == 'all') {
            $processes = $indexer->getProcessesCollection();
        } else {
            $codes = explode(',', $string);
            foreach ($codes as $code) {
                $process = $indexer->getProcessByCode(trim($code));
                if ($process) {
                    $processes[] = $process;
                }
            }
        }

        /** @var $process Mage_Index_Model_Process */
        foreach ($processes as $process) {
			
            $process->reindexEverything();
        }
    }
	/*
	*** Send Error mail to admin
	*/
	private function getErrorEmail($Error)
	{
		if(!defined('ERROR_EMAIL'))
		  define('ERROR_EMAIL','siddiqui.208@gmail.com');
		if((!empty($Error)) && ($Error != ''))
		{
		  //send error mail when error
		  $headers  = '';
		  $headers .= 'Return-Path: <' . ERROR_EMAIL . '>' . "\n";         
		  $headers .= 'X-Mailer: PHP/' . phpversion() . "\n";
		  $headers .= 'From: "Priz GmbH" <' . ERROR_EMAIL . '>' . "\n";
		  $headers .= 'Reply-To: ' . ERROR_EMAIL . "\n";
		  $headers .= 'MIME-Version: 1.0' . "\n";
		  $headers .= 'Content-Type: text/plain; charset=UTF-8' . "\n";
		  $headers .= 'Content-Transfer-Encoding: 8bit' . "\n";
		  
		  $content2 = 'ERROR - '. basename ($_SERVER['PHP_SELF']) . "\n\n";
		  $content2 .= 'Datum: ' . date ('Y-m-d H:i:s') . "\n\n";
		  $content2 .= 'Error --> '.$Error. "\n";
		  mail (ERROR_EMAIL, 'ERROR - Magmi Import - '.basename ($_SERVER['PHP_SELF']), $content2, $headers);
		}      
	}	
	/*
	*** Send Success mail to admin
	*/
	private function getSuccessEmail($success)
	{
		if(!defined('SUCCESS_EMAIL'))
		  define('SUCCESS_EMAIL','siddiqui.208@gmail.com');
		if((!empty($success)) && ($success != ''))
		{
		  //send success mail when success
		  $headers  = '';
		  $headers .= 'Return-Path: <' . SUCCESS_EMAIL . '>' . "\n";         
		  $headers .= 'X-Mailer: PHP/' . phpversion() . "\n";
		  $headers .= 'From: "Priz GmbH" <' . SUCCESS_EMAIL . '>' . "\n";
		  $headers .= 'Reply-To: ' . SUCCESS_EMAIL . "\n";
		  $headers .= 'MIME-Version: 1.0' . "\n";
		  $headers .= 'Content-Type: text/plain; charset=UTF-8' . "\n";
		  $headers .= 'Content-Transfer-Encoding: 8bit' . "\n";
		  
		  $content2 = 'Finish Datum: ' . date ('Y-m-d H:i:s') . "\n\n";
		  $content2 .= 'success --> '.$success. "\n";
		  mail (SUCCESS_EMAIL, 'Magmi Import - Successfully - Import csv file '.basename ($_SERVER['PHP_SELF']), $content2, $headers);
		}          
	}
	/*
	*** Send inprocess mail to admin
	*/
	private function getInprocessEmail($inprocess)
	{
		if(!defined('INPRCCESS_EMAIL'))
		  define('INPRCCESS_EMAIL','siddiqui.208@gmail.com');
		if((!empty($inprocess)) && ($inprocess != ''))
		{
		  //send inprocess mail when inprocess
		  $headers  = '';
		  $headers .= 'Return-Path: <' . INPRCCESS_EMAIL . '>' . "\n";         
		  $headers .= 'X-Mailer: PHP/' . phpversion() . "\n";
		  $headers .= 'From: "Priz GmbH" <' . INPRCCESS_EMAIL . '>' . "\n";
		  $headers .= 'Reply-To: ' . INPRCCESS_EMAIL . "\n";
		  $headers .= 'MIME-Version: 1.0' . "\n";
		  $headers .= 'Content-Type: text/plain; charset=UTF-8' . "\n";
		  $headers .= 'Content-Transfer-Encoding: 8bit' . "\n";
		  
		  $content2 = 'inprocess - See message Below:-'. "\n\n";
		  $content2 .= 'Datum: ' . date ('Y-m-d H:i:s') . "\n\n";
		  $content2 .= 'inprocess --> '.$inprocess. "\n";
		  mail (INPRCCESS_EMAIL, 'Magmi Import - Inprocess - csv file import '.basename ($_SERVER['PHP_SELF']), $content2, $headers);
		}          
	}	
	/*
	*** Set check attribute create or not
	** return function create attribute
	**/
	private function getAttributeCreate($checkArr = array())
	{
		//$csvData = fopen($checkArr, "r");
		//$listData =fgetcsv($csvData);
		
		$skipValue = array("store","storeid","attributeset","type", "productwebsites", "websites", "qty", "isinstock", "managestock","useconfigminqty","useconfigqtyincrements","minqty","tierpriceall", "sku");
		
		foreach($checkArr as $codeValue)
		{
			$convertItem = iconv("UTF-8", "ISO-8859-2//TRANSLIT", trim($codeValue));

			$collection = Mage::getResourceModel('catalog/eav_attribute')->loadByCode('catalog_product', $convertItem);
			$collection_Item = $collection->getId();
			if(empty($collection_Item))
			{
				$code_item = preg_replace('/[^A-Za-z0-9\-]/', '', $convertItem);

				//skip value from array
				if(in_array($code_item, $skipValue)) continue;
				//create new attribute if not exist
				$convertUtfValue = utf8_encode(strtolower($convertItem));
				$convertUtfValue_label = ucfirst(str_replace("_"," ",utf8_encode($convertItem)));
				$installer = new Mage_Eav_Model_Entity_Setup('core_setup');
				$installer->addAttribute("catalog_product", "$convertUtfValue",  array(
					"type"     => "int",
					"frontend" => "",
					"label"    => "$convertUtfValue_label",
					"input"    => "select",
					"backend"  => "eav/entity_attribute_backend_array",	
					"global"   => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
					"apply_to" => Mage_Catalog_Model_Product_Type::TYPE_SIMPLE.','.Mage_Catalog_Model_Product_Type::TYPE_CONFIGURABLE.','.Mage_Catalog_Model_Product_Type::TYPE_VIRTUAL.','.Mage_Catalog_Model_Product_Type::TYPE_BUNDLE.','.Mage_Downloadable_Model_Product_Type::TYPE_DOWNLOADABLE,					
					"visible"  => true,
					"required" => false,
					"user_defined"  => false,
					"default" => "",
					"searchable" => true,
					"visible_in_advanced_search" => true,
					"filterable" => false,
					"comparable" => false,
					"visible_on_front"  => true,
					'filterable_in_search'  => true,					
					"unique"     => false,
					"note"       => "",
				));
					$installer->updateAttribute('catalog_product', "$convertUtfValue", 'is_user_defined', 1);
					$installer->updateAttribute('catalog_product', "$convertUtfValue", 'is_configurable', 1);
					$installer->updateAttribute('catalog_product', "$convertUtfValue", 'is_searchable', 1);
					$installer->updateAttribute('catalog_product', "$convertUtfValue", 'is_visible_in_advanced_search', 1);
					$installer->updateAttribute('catalog_product', "$convertUtfValue", 'is_visible_on_front', 0);
					$installer->updateAttribute('catalog_product', "$convertUtfValue", 'is_filterable', 1);
					$installer->updateAttribute('catalog_product', "$convertUtfValue", 'is_filterable_in_search', 1);
					$installer->updateAttribute('catalog_product', "$convertUtfValue", 'is_html_allowed_on_front', 1);		
			}
		}
	}
}